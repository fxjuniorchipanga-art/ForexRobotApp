package com.forexrobot.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoboV2() }
    }
}

@Composable
fun RoboV2() {
    var asset by remember { mutableStateOf("XAUUSD") }
    var result by remember { mutableStateOf("NO TRADE") }

    MaterialTheme {
        Scaffold(topBar={TopAppBar(title={Text("Robô V2")})}) { p ->
            LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                item { Text("AI Forex Analysis", style=MaterialTheme.typography.headlineSmall) }
                item { Text("Primeira versão do nosso aplicativo.") }
                item {
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        listOf("XAUUSD","EURUSD","GBPUSD","USDJPY").forEach { s ->
                            FilterChip(asset==s, onClick={asset=s}, label={Text(s)})
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Motor de análise", style=MaterialTheme.typography.titleMedium)
                            Text("EMA 50/200 • RSI • ATR • Volume")
                            Text("Liquidity Sweep • BOS/CHOCH • FVG")
                            Text("Order Block • Fibonacci • Volume Profile")
                            Text("Candlesticks • Confluence Score")
                        }
                    }
                }
                item {
                    Button(onClick={result="NO TRADE"}, Modifier.fillMaxWidth()) {
                        Text("ANALISAR AGORA")
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Resultado: $result", style=MaterialTheme.typography.headlineSmall)
                            Text("Ativo: $asset")
                            Text("Score: —/10")
                            Text("Entrada: —   SL: —")
                            Text("TP1 / TP2 / TP3: —")
                        }
                    }
                }
                item { Text("Sem martingale. O sistema pode retornar NO TRADE.") }
            }
        }
    }
}
